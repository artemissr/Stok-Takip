import type { NextFunction, Request, Response } from "express";

// Express 5 forwards rejected promises to error middleware automatically,
// but wrapping keeps route bodies free of repetitive try/catch blocks and
// makes the intent (this can throw, that's fine) explicit at the call site.
export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>,
) {
  return (req: Request, res: Response, next: NextFunction) => {
    fn(req, res, next).catch(next);
  };
}

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

export function notFound(entity: string): never {
  throw new HttpError(404, `${entity} bulunamadı`);
}
