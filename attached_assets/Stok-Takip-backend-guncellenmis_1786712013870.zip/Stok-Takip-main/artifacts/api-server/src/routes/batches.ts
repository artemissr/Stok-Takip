import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, batchesTable, insertBatchSchema } from "@workspace/db";
import { asyncHandler, notFound } from "../lib/asyncHandler";

const router: IRouter = Router();

router.get(
  "/batches",
  asyncHandler(async (req, res) => {
    const { ingredientId } = req.query;
    const query = db.select().from(batchesTable);
    const rows =
      typeof ingredientId === "string"
        ? await query.where(eq(batchesTable.ingredientId, ingredientId))
        : await query;
    res.json(rows);
  }),
);

// A "shipment" is just a new batch — kept as its own endpoint name in the
// mobile app's vocabulary (addShipment) even though it's the same table.
router.post(
  "/batches",
  asyncHandler(async (req, res) => {
    const input = insertBatchSchema.parse(req.body);
    const [row] = await db.insert(batchesTable).values(input).returning();
    res.status(201).json(row);
  }),
);

router.delete(
  "/batches/:id",
  asyncHandler(async (req, res) => {
    const [row] = await db
      .delete(batchesTable)
      .where(eq(batchesTable.id, req.params.id))
      .returning();
    if (!row) notFound("Sevkiyat kaydı");
    res.status(204).send();
  }),
);

export default router;
