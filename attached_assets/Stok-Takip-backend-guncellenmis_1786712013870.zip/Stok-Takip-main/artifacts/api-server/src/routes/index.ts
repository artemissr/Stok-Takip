import { Router, type IRouter } from "express";
import healthRouter from "./health";
import ingredientsRouter from "./ingredients";
import batchesRouter from "./batches";
import recipesRouter from "./recipes";
import salesRouter from "./sales";
import returnsRouter from "./returns";
import schedulesRouter from "./schedules";

const router: IRouter = Router();

router.use(healthRouter);
router.use(ingredientsRouter);
router.use(batchesRouter);
router.use(recipesRouter);
router.use(salesRouter);
router.use(returnsRouter);
router.use(schedulesRouter);

export default router;
