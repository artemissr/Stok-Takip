import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, ingredientsTable, insertIngredientSchema, updateIngredientSchema } from "@workspace/db";
import { asyncHandler, notFound } from "../lib/asyncHandler";

const router: IRouter = Router();

router.get(
  "/ingredients",
  asyncHandler(async (_req, res) => {
    const rows = await db.select().from(ingredientsTable);
    res.json(rows);
  }),
);

router.get(
  "/ingredients/:id",
  asyncHandler(async (req, res) => {
    const [row] = await db
      .select()
      .from(ingredientsTable)
      .where(eq(ingredientsTable.id, req.params.id));
    if (!row) notFound("Ürün");
    res.json(row);
  }),
);

router.post(
  "/ingredients",
  asyncHandler(async (req, res) => {
    const input = insertIngredientSchema.parse(req.body);
    const [row] = await db.insert(ingredientsTable).values(input).returning();
    res.status(201).json(row);
  }),
);

router.patch(
  "/ingredients/:id",
  asyncHandler(async (req, res) => {
    const input = updateIngredientSchema.parse(req.body);
    const [row] = await db
      .update(ingredientsTable)
      .set(input)
      .where(eq(ingredientsTable.id, req.params.id))
      .returning();
    if (!row) notFound("Ürün");
    res.json(row);
  }),
);

router.delete(
  "/ingredients/:id",
  asyncHandler(async (req, res) => {
    const [row] = await db
      .delete(ingredientsTable)
      .where(eq(ingredientsTable.id, req.params.id))
      .returning();
    if (!row) notFound("Ürün");
    res.status(204).send();
  }),
);

export default router;
