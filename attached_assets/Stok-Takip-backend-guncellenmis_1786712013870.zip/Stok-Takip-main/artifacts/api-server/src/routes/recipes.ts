import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, recipesTable, recipeIngredientsTable, createRecipeSchema } from "@workspace/db";
import { asyncHandler, notFound } from "../lib/asyncHandler";

const router: IRouter = Router();

router.get(
  "/recipes",
  asyncHandler(async (_req, res) => {
    const recipes = await db.select().from(recipesTable);
    const lines = await db.select().from(recipeIngredientsTable);
    res.json(
      recipes.map((recipe) => ({
        ...recipe,
        ingredients: lines.filter((line) => line.recipeId === recipe.id),
      })),
    );
  }),
);

router.get(
  "/recipes/:id",
  asyncHandler(async (req, res) => {
    const [recipe] = await db.select().from(recipesTable).where(eq(recipesTable.id, req.params.id));
    if (!recipe) notFound("Reçete");
    const ingredients = await db
      .select()
      .from(recipeIngredientsTable)
      .where(eq(recipeIngredientsTable.recipeId, req.params.id));
    res.json({ ...recipe, ingredients });
  }),
);

router.post(
  "/recipes",
  asyncHandler(async (req, res) => {
    const { ingredients, ...recipeInput } = createRecipeSchema.parse(req.body);

    const recipe = await db.transaction(async (tx) => {
      const [row] = await tx.insert(recipesTable).values(recipeInput).returning();
      await tx.insert(recipeIngredientsTable).values(
        ingredients.map((line) => ({
          recipeId: row.id,
          ingredientId: line.ingredientId,
          quantity: line.quantity,
        })),
      );
      return row;
    });

    res.status(201).json({ ...recipe, ingredients });
  }),
);

router.delete(
  "/recipes/:id",
  asyncHandler(async (req, res) => {
    const [row] = await db.delete(recipesTable).where(eq(recipesTable.id, req.params.id)).returning();
    if (!row) notFound("Reçete");
    res.status(204).send();
  }),
);

export default router;
