import { Router, type IRouter } from "express";
import { db, returnsTable, insertReturnSchema } from "@workspace/db";
import { asyncHandler } from "../lib/asyncHandler";

const router: IRouter = Router();

router.get(
  "/returns",
  asyncHandler(async (_req, res) => {
    const rows = await db.select().from(returnsTable);
    res.json(rows);
  }),
);

// Tracking-only, per product decision: a return is logged for history but
// does not add quantity back to any batch (returned stock is treated as
// already gone / sent back to the supplier).
router.post(
  "/returns",
  asyncHandler(async (req, res) => {
    const input = insertReturnSchema.parse(req.body);
    const [row] = await db.insert(returnsTable).values(input).returning();
    res.status(201).json(row);
  }),
);

export default router;
