import { Router, type IRouter } from "express";
import { asc, eq } from "drizzle-orm";
import {
  db,
  salesTable,
  batchesTable,
  recipesTable,
  recipeIngredientsTable,
  recordSaleSchema,
} from "@workspace/db";
import { asyncHandler, notFound, HttpError } from "../lib/asyncHandler";

const router: IRouter = Router();

router.get(
  "/sales",
  asyncHandler(async (_req, res) => {
    const rows = await db.select().from(salesTable);
    res.json(rows);
  }),
);

// Records a sale and consumes stock across batches oldest-expiry-first,
// mirroring the FIFO logic the mobile app previously did locally against
// AsyncStorage in InventoryContext.recordSale. Runs as one transaction so a
// sale is never recorded without the matching stock deduction (or vice versa).
router.post(
  "/sales",
  asyncHandler(async (req, res) => {
    const input = recordSaleSchema.parse(req.body);

    const sale = await db.transaction(async (tx) => {
      const [recipe] = await tx.select().from(recipesTable).where(eq(recipesTable.id, input.recipeId));
      if (!recipe) notFound("Reçete");

      const lines = await tx
        .select()
        .from(recipeIngredientsTable)
        .where(eq(recipeIngredientsTable.recipeId, input.recipeId));

      for (const line of lines) {
        const required = line.quantity * input.quantity;
        const batches = await tx
          .select()
          .from(batchesTable)
          .where(eq(batchesTable.ingredientId, line.ingredientId))
          .orderBy(asc(batchesTable.expiryDate));

        const available = batches.reduce((sum, batch) => sum + batch.quantity, 0);
        if (available < required) {
          throw new HttpError(409, `Yetersiz stok: ${line.ingredientId}`);
        }

        let remaining = required;
        for (const batch of batches) {
          if (remaining <= 0) break;
          if (batch.quantity <= 0) continue;
          const taken = Math.min(remaining, batch.quantity);
          await tx
            .update(batchesTable)
            .set({ quantity: batch.quantity - taken })
            .where(eq(batchesTable.id, batch.id));
          remaining -= taken;
        }
      }

      const [row] = await tx
        .insert(salesTable)
        .values({ recipeId: input.recipeId, quantity: input.quantity })
        .returning();
      return row;
    });

    res.status(201).json(sale);
  }),
);

export default router;
