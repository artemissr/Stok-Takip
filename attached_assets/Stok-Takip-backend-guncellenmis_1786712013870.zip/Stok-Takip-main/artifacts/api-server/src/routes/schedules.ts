import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, schedulesTable, updateSchedulesSchema } from "@workspace/db";
import { asyncHandler } from "../lib/asyncHandler";

const router: IRouter = Router();
const SINGLETON_ID = 1;

router.get(
  "/schedules",
  asyncHandler(async (_req, res) => {
    const [row] = await db.select().from(schedulesTable).where(eq(schedulesTable.id, SINGLETON_ID));
    res.json(row ?? { id: SINGLETON_ID, orderDays: [], shipmentDays: [], notificationsEnabled: false });
  }),
);

router.put(
  "/schedules",
  asyncHandler(async (req, res) => {
    const input = updateSchedulesSchema.parse(req.body);
    const [row] = await db
      .insert(schedulesTable)
      .values({ id: SINGLETON_ID, ...input })
      .onConflictDoUpdate({
        target: schedulesTable.id,
        set: input,
      })
      .returning();
    res.json(row);
  }),
);

export default router;
