import { pgTable, text, numeric, date, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { ingredientsTable, areaEnum } from "./ingredients";

// A batch = one shipment/received lot of an ingredient, tracked separately so
// FIFO-by-expiry consumption (oldest expiry first) works the same way the
// mobile app's local recordSale() logic already does.
export const batchesTable = pgTable("batches", {
  id: uuid("id").primaryKey().defaultRandom(),
  ingredientId: uuid("ingredient_id")
    .notNull()
    .references(() => ingredientsTable.id, { onDelete: "cascade" }),
  quantity: numeric("quantity", { precision: 12, scale: 3, mode: "number" }).notNull(),
  // Nullable: frozen items don't require an expiry date (per product requirement).
  expiryDate: date("expiry_date"),
  receivedAt: date("received_at").notNull().defaultNow(),
  area: areaEnum("area").notNull(),
  imageUri: text("image_uri"),
});

export const insertBatchSchema = createInsertSchema(batchesTable).omit({ id: true, receivedAt: true });
export const selectBatchSchema = createSelectSchema(batchesTable);

export type InsertBatch = z.infer<typeof insertBatchSchema>;
export type Batch = typeof batchesTable.$inferSelect;
