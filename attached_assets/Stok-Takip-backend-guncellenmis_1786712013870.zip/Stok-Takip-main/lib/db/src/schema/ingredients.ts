import { pgTable, text, numeric, integer, jsonb, pgEnum, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod/v4";

// Mirrors MainCategory / Area from the mobile app's InventoryContext.
// NOTE: these are onboarding-configurable per business long-term (see replit.md
// "Architecture decisions"). Kept as enums for now since only one business uses
// this instance; revisit if/when the app supports multiple businesses.
export const mainCategoryEnum = pgEnum("main_category", ["Bar", "Mutfak", "Tezgah"]);
export const areaEnum = pgEnum("area", [
  "Soğuk depo",
  "Kuru depo",
  "Bar",
  "Dondurucu",
  "Sarf malzeme",
]);

export const ingredientsTable = pgTable("ingredients", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  unit: text("unit").notNull(),
  buyPrice: numeric("buy_price", { precision: 12, scale: 2, mode: "number" }).notNull(),
  salePrice: numeric("sale_price", { precision: 12, scale: 2, mode: "number" }).notNull(),
  area: areaEnum("area").notNull(),
  mainCategory: mainCategoryEnum("main_category").notNull(),
  threshold: numeric("threshold", { precision: 12, scale: 3, mode: "number" }).notNull(),
  content: text("content").notNull().default(""),
  calories: integer("calories").notNull().default(0),
  allergens: jsonb("allergens").$type<string[]>().notNull().default([]),
  barcode: text("barcode"),
});

export const insertIngredientSchema = createInsertSchema(ingredientsTable).omit({ id: true });
export const selectIngredientSchema = createSelectSchema(ingredientsTable);
export const updateIngredientSchema = insertIngredientSchema.partial();

export type InsertIngredient = z.infer<typeof insertIngredientSchema>;
export type Ingredient = typeof ingredientsTable.$inferSelect;
