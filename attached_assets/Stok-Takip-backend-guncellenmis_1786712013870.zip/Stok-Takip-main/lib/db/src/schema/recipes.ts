import { pgTable, text, numeric, uuid, primaryKey } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { ingredientsTable } from "./ingredients";

export const recipesTable = pgTable("recipes", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  salePrice: numeric("sale_price", { precision: 12, scale: 2, mode: "number" }).notNull(),
});

// Join table: how much of each ingredient one recipe unit consumes.
export const recipeIngredientsTable = pgTable(
  "recipe_ingredients",
  {
    recipeId: uuid("recipe_id")
      .notNull()
      .references(() => recipesTable.id, { onDelete: "cascade" }),
    ingredientId: uuid("ingredient_id")
      .notNull()
      .references(() => ingredientsTable.id, { onDelete: "restrict" }),
    quantity: numeric("quantity", { precision: 12, scale: 4, mode: "number" }).notNull(),
  },
  (table) => [primaryKey({ columns: [table.recipeId, table.ingredientId] })],
);

export const insertRecipeSchema = createInsertSchema(recipesTable).omit({ id: true });
export const selectRecipeSchema = createSelectSchema(recipesTable);
export const recipeIngredientInputSchema = z.object({
  ingredientId: z.string().uuid(),
  quantity: z.number().positive(),
});

// Body shape for POST /recipes: recipe fields + its ingredient lines together,
// since a recipe with no ingredients isn't useful.
export const createRecipeSchema = insertRecipeSchema.extend({
  ingredients: z.array(recipeIngredientInputSchema).min(1),
});

export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type Recipe = typeof recipesTable.$inferSelect;
export type CreateRecipeInput = z.infer<typeof createRecipeSchema>;
