import { pgTable, text, numeric, date, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { ingredientsTable } from "./ingredients";

// Tracking-only: returned stock is treated as gone (sent back to supplier),
// this table exists so it shows up in reports/history, not to re-add stock.
export const returnsTable = pgTable("returns", {
  id: uuid("id").primaryKey().defaultRandom(),
  ingredientId: uuid("ingredient_id")
    .notNull()
    .references(() => ingredientsTable.id, { onDelete: "cascade" }),
  quantity: numeric("quantity", { precision: 12, scale: 3, mode: "number" }).notNull(),
  date: date("date").notNull().defaultNow(),
  reason: text("reason").notNull().default(""),
});

export const insertReturnSchema = createInsertSchema(returnsTable).omit({ id: true, date: true });
export const selectReturnSchema = createSelectSchema(returnsTable);

export type InsertReturn = z.infer<typeof insertReturnSchema>;
export type ReturnRecord = typeof returnsTable.$inferSelect;
