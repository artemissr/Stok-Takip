import { pgTable, integer, date, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { recipesTable } from "./recipes";

export const salesTable = pgTable("sales", {
  id: uuid("id").primaryKey().defaultRandom(),
  recipeId: uuid("recipe_id")
    .notNull()
    .references(() => recipesTable.id, { onDelete: "restrict" }),
  quantity: integer("quantity").notNull(),
  date: date("date").notNull().defaultNow(),
});

// Only recipeId + quantity are client-supplied; the server stamps the date
// and decides whether stock covers it (see routes/sales.ts).
export const recordSaleSchema = z.object({
  recipeId: z.string().uuid(),
  quantity: z.number().int().positive(),
});

export const selectSaleSchema = createSelectSchema(salesTable);

export type Sale = typeof salesTable.$inferSelect;
export type RecordSaleInput = z.infer<typeof recordSaleSchema>;

// Re-exported for symmetry with other schema files even though it's unused
// directly (insertion always goes through recordSaleSchema above).
export const insertSaleSchema = createInsertSchema(salesTable).omit({ id: true });
