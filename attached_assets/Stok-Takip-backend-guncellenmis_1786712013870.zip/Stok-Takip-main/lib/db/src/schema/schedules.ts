import { pgTable, integer, jsonb, boolean } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

// Single-row settings table (one business per instance today). id is always
// 1 — routes always upsert onto that row rather than creating new ones.
// NOTE: if the app ever supports multiple businesses, this becomes
// per-business keyed rather than a singleton.
export const schedulesTable = pgTable("schedules", {
  id: integer("id").primaryKey().default(1),
  orderDays: jsonb("order_days").$type<number[]>().notNull().default([]),
  shipmentDays: jsonb("shipment_days").$type<number[]>().notNull().default([]),
  notificationsEnabled: boolean("notifications_enabled").notNull().default(false),
});

export const updateSchedulesSchema = z.object({
  orderDays: z.array(z.number().int().min(0).max(6)),
  shipmentDays: z.array(z.number().int().min(0).max(6)),
});

export type Schedules = typeof schedulesTable.$inferSelect;
export type UpdateSchedulesInput = z.infer<typeof updateSchedulesSchema>;
