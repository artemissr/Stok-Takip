import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  ApiError,
  createBatch,
  createIngredient,
  createRecipe,
  createReturn,
  fetchBatches,
  fetchIngredients,
  fetchRecipes,
  fetchReturns,
  fetchSales,
  fetchSchedules,
  recordSaleRequest,
  updateSchedulesRequest,
} from './apiClient';

export type MainCategory = 'Bar' | 'Mutfak' | 'Tezgah';
export type Area = 'Soğuk depo' | 'Kuru depo' | 'Bar' | 'Dondurucu' | 'Sarf malzeme';

export const MAIN_CATEGORIES: MainCategory[] = ['Bar', 'Mutfak', 'Tezgah'];
export const AREAS: Area[] = ['Soğuk depo', 'Kuru depo', 'Bar', 'Dondurucu', 'Sarf malzeme'];

export type Ingredient = {
  id: string;
  name: string;
  unit: string;
  buyPrice: number;
  salePrice: number;
  area: Area;
  mainCategory: MainCategory;
  threshold: number;
  content: string;
  calories: number;
  allergens: string[];
  barcode?: string;
};

export type Batch = {
  id: string;
  ingredientId: string;
  quantity: number;
  expiryDate: string;
  receivedAt: string;
  area: Area;
  imageUri?: string;
};

export type RecipeIngredient = {
  ingredientId: string;
  quantity: number;
};

export type Recipe = {
  id: string;
  name: string;
  salePrice: number;
  ingredients: RecipeIngredient[];
};

export type Sale = {
  id: string;
  recipeId: string;
  quantity: number;
  date: string;
};

export type ReturnRecord = {
  id: string;
  ingredientId: string;
  quantity: number;
  date: string;
  reason: string;
};

type InventoryData = {
  ingredients: Ingredient[];
  batches: Batch[];
  recipes: Recipe[];
  sales: Sale[];
  returns: ReturnRecord[];
  schedules: {
    orderDays: number[];
    shipmentDays: number[];
  };
};

export const today = () => new Date().toISOString().slice(0, 10);

const emptyData: InventoryData = {
  ingredients: [],
  batches: [],
  recipes: [],
  sales: [],
  returns: [],
  schedules: { orderDays: [], shipmentDays: [] },
};

// The API returns nullable columns (barcode, expiryDate) as `null`; the
// mobile app's types use `undefined` / a display-safe string instead.
function normalizeIngredient(row: Ingredient): Ingredient {
  return { ...row, barcode: row.barcode ?? undefined };
}
function normalizeBatch(row: Batch): Batch {
  // A batch can have no expiry (frozen items don't require one). There's no
  // UI yet to leave the field blank when creating a shipment, so this only
  // shows up for rows inserted outside the app — fall back to today so
  // date-math helpers (`daysUntil`) don't choke on an empty string.
  return { ...row, expiryDate: row.expiryDate || today() };
}

type InventoryContextValue = InventoryData & {
  hydrated: boolean;
  loadError: string | null;
  refresh: () => void;
  addIngredient: (input: Omit<Ingredient, 'id'>) => Promise<void>;
  addShipment: (input: Omit<Batch, 'id' | 'receivedAt'>) => Promise<void>;
  addRecipe: (input: Omit<Recipe, 'id'>) => Promise<void>;
  addReturn: (input: Omit<ReturnRecord, 'id'>) => Promise<void>;
  updateSchedules: (schedules: InventoryData['schedules']) => Promise<void>;
  recordSale: (recipeId: string, quantity: number) => Promise<boolean>;
};

const InventoryContext = createContext<InventoryContextValue | null>(null);

export function InventoryProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<InventoryData>(emptyData);
  const [hydrated, setHydrated] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const loadAll = useCallback(() => {
    setLoadError(null);
    Promise.all([fetchIngredients(), fetchBatches(), fetchRecipes(), fetchSales(), fetchReturns(), fetchSchedules()])
      .then(([ingredients, batches, recipes, sales, returns, schedules]) => {
        setData({
          ingredients: ingredients.map(normalizeIngredient),
          batches: batches.map(normalizeBatch),
          recipes,
          sales,
          returns,
          schedules,
        });
      })
      .catch((error: unknown) => {
        setLoadError(error instanceof ApiError ? error.message : 'Sunucuya bağlanılamadı.');
      })
      .finally(() => setHydrated(true));
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const value = useMemo<InventoryContextValue>(() => ({
    ...data,
    hydrated,
    loadError,
    refresh: loadAll,
    addIngredient: async (input) => {
      const created = normalizeIngredient(await createIngredient(input));
      setData((previous) => ({ ...previous, ingredients: [...previous.ingredients, created] }));
    },
    addShipment: async (input) => {
      const created = normalizeBatch(await createBatch(input));
      setData((previous) => ({ ...previous, batches: [...previous.batches, created] }));
    },
    addRecipe: async (input) => {
      const created = await createRecipe(input);
      setData((previous) => ({ ...previous, recipes: [...previous.recipes, created] }));
    },
    addReturn: async (input) => {
      const created = await createReturn(input);
      setData((previous) => ({ ...previous, returns: [...previous.returns, created] }));
    },
    updateSchedules: async (schedules) => {
      const saved = await updateSchedulesRequest(schedules);
      setData((previous) => ({ ...previous, schedules: saved }));
    },
    recordSale: async (recipeId, quantity) => {
      if (quantity <= 0) return false;
      try {
        const sale = await recordSaleRequest(recipeId, quantity);
        // The server did the FIFO deduction across batches — refetch rather
        // than recompute it client-side so displayed stock stays authoritative.
        const freshBatches = await fetchBatches();
        setData((previous) => ({
          ...previous,
          sales: [...previous.sales, sale],
          batches: freshBatches.map(normalizeBatch),
        }));
        return true;
      } catch (error) {
        if (error instanceof ApiError && error.status === 409) return false;
        throw error;
      }
    },
  }), [data, hydrated, loadError, loadAll]);

  return <InventoryContext.Provider value={value}>{children}</InventoryContext.Provider>;
}

export function useInventory() {
  const context = useContext(InventoryContext);
  if (!context) throw new Error('useInventory must be used inside InventoryProvider');
  return context;
}

export function stockFor(batches: Batch[], ingredientId: string) {
  return batches
    .filter((batch) => batch.ingredientId === ingredientId)
    .reduce((sum, batch) => sum + batch.quantity, 0);
}

export function formatDate(value: string) {
  return new Intl.DateTimeFormat('tr-TR', { day: 'numeric', month: 'short' }).format(new Date(`${value}T12:00:00`));
}

export function daysUntil(value: string) {
  const start = new Date(`${today()}T12:00:00`).getTime();
  const end = new Date(`${value}T12:00:00`).getTime();
  return Math.ceil((end - start) / 86400000);
}
