# Stok Kontrolüm

Gıda/restoran işletmeleri için stok sayısı, SKT (son kullanma tarihi) ve satış takibi yapan uygulama.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec (run this after editing openapi.yaml)
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Mobile app: Expo / React Native (artifacts/restaurant-stock-tracker)

## Where things live

- `lib/db/src/schema/` — Drizzle tables: `ingredients.ts`, `batches.ts`, `recipes.ts` (+ join table `recipe_ingredients`), `sales.ts`, `returns.ts`, `schedules.ts` (singleton settings row)
- `artifacts/api-server/src/routes/` — one file per entity, CRUD only; business logic (FIFO stock consumption on sale) lives in `routes/sales.ts`
- `artifacts/api-server/src/lib/asyncHandler.ts` — wraps route handlers, `HttpError` for typed error responses
- `artifacts/api-server/src/middlewares/errorHandler.ts` — turns ZodError/HttpError into consistent JSON error responses
- `lib/api-spec/openapi.yaml` — source of truth for API contracts; frontend hooks generated from this via Orval codegen (not yet wired into the mobile app)
- `artifacts/restaurant-stock-tracker/context/apiClient.ts` — hand-written fetch client the mobile app uses to talk to `api-server` (see Gotchas — not Orval-generated yet)
- `artifacts/restaurant-stock-tracker/context/InventoryContext.tsx` — app-wide state; fetches from the API on mount and mirrors it locally, mutations are async and call the API before updating local state

## Architecture decisions

- Numeric DB columns (`price`, `quantity`, `threshold` etc.) use Drizzle's `mode: "number"` on `numeric()` so the API speaks plain JS numbers, matching what the mobile app's types already expect — avoids string/number coercion at the API boundary.
- Stock is tracked per **batch** (one row per shipment/lot), not as a single quantity on the ingredient. Selling consumes the oldest-`expiryDate` batch first (FIFO), mirroring the logic the mobile app used to do locally in `InventoryContext.recordSale`. Batches with no expiry (frozen items) sort last, so they're only consumed once dated stock runs out.
- Returns are tracking-only: `POST /returns` never adds quantity back to a batch — per product decision, returned stock is treated as already gone (sent back to supplier), the endpoint exists purely for reporting/history.
- `schedules` is a single-row (id=1) table, not per-user — there's only one business per instance right now. If the app becomes multi-tenant, this needs to become a keyed table.
- Recipe creation (`POST /recipes`) takes the recipe plus its ingredient lines in one request body and writes both inside a DB transaction, since a recipe with zero ingredients isn't a valid state.

## Product

- Ürün kartları (kalori/alerjen bilgisi ayrı sekmede), sevkiyat/parti bazlı stok takibi, SKT'ye göre otomatik stok düşümü, reçete bazlı satış kaydı, iade takibi, sipariş/sevkiyat bildirim takvimi.
- Henüz backend'de karşılığı olmayan (mobile-app-only veya hiç yapılmamış) özellikler: çalışan/yetki yönetimi, ses komutu, fatura görselleştirme, satış tahmini/kampanya önerileri, POS entegrasyonu, döviz paneli, menü QR okutma.

## Gotchas

- **Mobile app now calls the API** via a hand-written fetch client (`context/apiClient.ts`), not AsyncStorage — but this requires `EXPO_PUBLIC_API_URL` to be set (see `.env.example` in `artifacts/restaurant-stock-tracker`) to the api-server's *reachable* base URL. Without it, the app shows a "sunucuya bağlanılamadı" screen with a retry button instead of loading data.
- `context/apiClient.ts` is hand-written, not Orval-generated — it was built directly against the routes in `artifacts/api-server/src/routes/`, not through the `@workspace/api-client-react` codegen path. Once `pnpm --filter @workspace/api-spec run codegen` has been run (see below), consider migrating to the generated hooks for consistency with the rest of the workspace's tooling.
- After changing `lib/api-spec/openapi.yaml`, run `pnpm --filter @workspace/api-spec run codegen` before the frontend can use new endpoints via the generated client — it wasn't run as part of this change (no network access in the environment that made it), so `lib/api-client-react` is still stale relative to the spec.
- `numeric` Postgres columns without `mode: "number"` return strings from the driver — if you add a new numeric column, set the mode explicitly or you'll get silent string/number bugs.
- Returns/batches created with no `expiryDate` normalize to today's date on the client for display purposes only (see `normalizeBatch` in `InventoryContext.tsx`) — the underlying DB value is still `null`. There's no UI yet to leave the field blank when creating a shipment.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
